package Characters;

public class Elf extends Character{
	
	public Elf() {
		super.setHp(40);
		super.setStrength(4);
		super.setDefense(2);
		super.setAgility(7);
		super.setSpeed(7);
	}
	 
}
