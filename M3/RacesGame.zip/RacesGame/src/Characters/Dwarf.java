package Characters;

public class Dwarf extends Character{
	
	public Dwarf() {
		super.setHp(60);
		super.setStrength(6);
		super.setDefense(4);
		super.setAgility(5);
		super.setSpeed(3 );
	}
}
