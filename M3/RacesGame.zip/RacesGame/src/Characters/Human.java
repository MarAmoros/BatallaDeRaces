package Characters;

public class Human extends Character{

	public Human() {
		super.setHp(50);
		super.setStrength(5);
		super.setDefense(3);
		super.setAgility(6);
		super.setSpeed(5);
	}
}
