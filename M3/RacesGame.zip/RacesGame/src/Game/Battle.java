package Game;

import Characters.*;
import Weapons.*;

public class Battle {
	public static void main(String[] args) {
		Elf Pimentan = new Elf();
		Pimentan.setObject(new Arc());
		System.out.println(Pimentan);
		
	}
}
