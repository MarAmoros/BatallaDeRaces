package Game;
import Characters.*;
import Weapons.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.*;
import java.io.*;
import java.util.*;

import javax.imageio.*;
import javax.swing.*;
import Weapons.*
;public class GraphicInterface {

	public static void main(String[] args) {
		
		new Frame();

	}

}
class Frame extends JFrame {
//Weapons and warriors
	WeaponContainer wep= new WeaponContainer();
	WarriorContainer war= new WarriorContainer();
	ArrayList<Weapon> weapons = new ArrayList<Weapon>();
	ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	Button[] warrButton;
	Button[] wepButton;
	int j=0;
//Your Character
	private Warrior alliedCharacter = null;
	private Weapon alliedWeapon=null;
//JPanel
	private JPanel characterSelection;
	private JPanel weaponSelection;
	private JPanel nameSelection;

	
	public Frame() {
		setSize ( 900, 600 );
		setLocationRelativeTo ( null ); //centering the frame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Races Game");
		setResizable(false);
		initComponent();
		characterSelection.setVisible(true);
		weaponSelection.setVisible(false);
		
		setVisible(true);
	}
	
	public void initComponent() {
		//warrior/weapon from database
			wep.setWeapons(weapons);
			war.setWarriors(warriors);
		warrButton=new Button[warriors.size()];
	//Character selection panel
		characterSelection=new JPanel();
		characterSelection.setLayout(new GridLayout(1,3));
		int i=0;
		//adding images
		for (Warrior w : warriors){
			BufferedImage image=w.getImage();
			image=resize(image,300,563);
			
	        warrButton[i]=new Button(new ImageIcon(image),i);
			characterSelection.add(warrButton[i]);				
			i++;
		}
		//when the images are clicked
		setCharacterListener();
		
		characterSelection.setVisible(false);
		add(characterSelection);
		
	//weapon selection panel
		weaponSelection=new JPanel();
		weaponSelection.setLayout(new GridLayout(3,3));
		//setWeaponListener();
	//Name Selection Panel
	nameSelection=new JPanel();
	nameSelection.setLayout(new GridLayout(4,1));
	JLabel chooseName=new JLabel("Choose this characters' name:");
	JTextField selectedName=new JTextField(20);
	nameSelection.add(chooseName);
	nameSelection.add(selectedName);
	
	
	}
	
//resize images
	public static BufferedImage resize(BufferedImage img, int newW, int newH) { 
	    Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	    BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = dimg.createGraphics();
	    g2d.drawImage(tmp, 0, 0, null);
	    g2d.dispose();

	    return dimg;
	}  
//Liteners
	public void setCharacterListener() {
		//botones bien
		
		for (j=0;j<warriors.size();j++) {
		warrButton[j].addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Button b = (Button) arg0.getSource();

						alliedCharacter=warriors.get(b.getId());
						
						System.out.println(alliedCharacter);
						characterSelection.setVisible(false);
						add(weaponSelection);
						//weapons
						int i =0;
							for (Weapon w : weapons){
								
								if (w.getRace().contains(warriors.get(b.getId()).getRace())) {
									System.out.println(w.getRace());
									
								BufferedImage image=w.getImage();
								image=resize(image,200,200);
								wepButton=new Button[weapons.size()];
						        wepButton[i]=new Button(new ImageIcon(image),i);
								weaponSelection.add(wepButton[i]);				
								i++;
							}
						}
						weaponSelection.setVisible(true);
							
					}
				}
			);
		}
		
		
							
					
				
			
		

		
	
			
					
		
		
				
			
	
	/*public void setWeaponListener() {
		
				//Axe
				axImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Axe();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.add(alliedCharacter.getImage());
								nameSelection.add(alliedWeapon.getImage());
							
								nameSelection.setVisible(true);
								
							}
						}
						);
				//Bow
				bowImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Bow();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//Dagger
				daggerImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Dagger();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//Dirk
				dirkImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Dirk();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//DoubleSwords
				doubleSwordsImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new DoubleSwords();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//Katana
				katanaImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Katana();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//Scimitar
				scimitarImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Scimitar();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
				//Sword
				swordImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new Sword();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
							
						}
						);
				//Two Handed Axe
				TwoHandedAxeImage.addMouseListener(
						new MouseAdapter() {
							
							@Override
							public void mouseClicked(MouseEvent arg0) {
								alliedWeapon= new TwoHandedAxe();
								alliedCharacter.setObject(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								add(nameSelection);
								nameSelection.setVisible(true);
							}
						}
						);
	}
		*/
	}




}

class Button extends JButton{
	private int id = 0;
	public Button(ImageIcon nombre, int id) {
		super(nombre);
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}


