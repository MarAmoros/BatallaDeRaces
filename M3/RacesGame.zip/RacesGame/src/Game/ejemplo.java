package Game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ejemplo extends JFrame implements ActionListener{
	public static void main(String[] args) {
		new ejemplo();
	}
	public ejemplo() {
		Panel panel = new Panel();
		panel.getBoton().addActionListener(this);;
		this.setSize(400,400);
		this.add(panel,BorderLayout.CENTER);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		BotonPersonalizado b = (BotonPersonalizado) e.getSource();
		System.out.println("atributo String "+b.getAtributo1());
		System.out.println("atributo int "+b.getAtributo2());
		
	}

}
class Panel extends JPanel{
	private BotonPersonalizado boton;
	public Panel() {
		boton = new BotonPersonalizado("Boton");
		this.add(boton);
		this.setBackground(Color.red);
	}
	public JButton getBoton() {
		return boton;
	}
}
class BotonPersonalizado extends JButton{
	private String atributo1= "atributo1";
	private int atributo2 = 2;
	public BotonPersonalizado(String nombre) {
		this.setText(nombre);
	}
	public String getAtributo1() {
		return atributo1;
	}
	public void setAtributo1(String atributo1) {
		this.atributo1 = atributo1;
	}
	public int getAtributo2() {
		return atributo2;
	}
	public void setAtributo2(int atributo2) {
		this.atributo2 = atributo2;
	}
	
}
