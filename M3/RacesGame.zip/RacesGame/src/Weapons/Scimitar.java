package Weapons;

public class Scimitar extends Weapon {

		public Scimitar() {
			super.setSpeed(2);
			super.setStrength(1);
		}
}
