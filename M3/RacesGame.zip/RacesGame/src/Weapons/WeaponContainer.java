package Weapons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Game.ImageComponent;

public class WeaponContainer {
    String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC",user="user",password="user";
    String query="select * from weapons";
    private ArrayList<Weapon> weapons= new ArrayList<Weapon>();


    public ArrayList<Weapon> getWeapons() {
        return weapons;
    }

    public void setWeapons(ArrayList<Weapon> weapons) {
        //BBDD connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("no se ha podido cargar el driver");
        }

            try {
                Connection con=DriverManager.getConnection(url, user, password);
                //STATEMENT
                Statement st=con.createStatement();
                ResultSet rs=st.executeQuery(query);


                while(rs.next()) {
                    Weapon w=new Weapon();
                    w.setId(rs.getInt(1));
                    w.setName(rs.getString(2));
                    w.setImage(rs.getString(3));
                    w.setRace(rs.getString(4));
                    w.setAttack(rs.getInt(5));
                    w.setSpeed(rs.getInt(6));
                    w.setPoints(rs.getInt(7));
                    weapons.add(w);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("no se ha podido Establecer la conexion");
            }



        this.weapons = weapons;




    }
}