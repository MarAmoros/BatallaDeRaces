package Weapons;

public class Dirk extends Weapon {

		public Dirk() {
			super.setSpeed(4);
			super.setStrength(0);
		}
}
