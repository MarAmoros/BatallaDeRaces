package Weapons;

public class Arc extends Weapon {

		public Arc() {
			super.setSpeed(5);
			super.setStrength(1);
		}
}
