package Weapons;

public class Dagger extends Weapon {

	public Dagger() {
		super.setSpeed(3);
		super.setStrength(0);
	}
}
