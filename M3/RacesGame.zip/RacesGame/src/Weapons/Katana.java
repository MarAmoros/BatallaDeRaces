package Weapons;

public class Katana extends Weapon {

	public Katana() {
		super.setSpeed(3);
		super.setStrength(2);
	}
}
