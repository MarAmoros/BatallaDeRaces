package Game;

import java.util.ArrayList;

import Characters.Warrior;
import Weapons.Weapon;
import Weapons.WeaponContainer;

public class Main {

	public static void main(String[] args) {
		

		

		Frame frame=new Frame(false,null);
		//new BattleInterfaces(frame.getAlliedCharacter(), frame.getAlliedCharacter());
		
		
	}

}
