package Game;
import Characters.*;
import Weapons.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.plaf.basic.BasicProgressBarUI;

import Weapons.*;

public class Frame extends JFrame {
	//Batle interface
	
	//Visual elements
		JPanel playerPanel, playerHBPanel, enemyPanel, enemyHBPanel, playPanel, attackPanel, battlePanel, optionPanel;
		JButton fight, attack, clearConsole;
		JTextArea console;
		JScrollPane scroll;
		JScrollBar bar;
		JButton buttons[] = new JButton[5];
		JProgressBar healthBar,strengthBar, dexterityBar,speedBar,defenseBar, playerHPBar, enemyHPBar ;
		String fightText ="";
		int playerID;
		//Battle attributes
		private Warrior localAlly=null, localEnemy=null;
		int playerTurn = 0, allyHP=0, enemyHP=0;
		
		//Connection attributes
	
	//BBDD
		private String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC";	
		private String user="user";
		private String password="";
		private String players="select * from players";
	 //boolean for warrior and weapon selection
		private int playerPoints=0;
//Weapons and warriors
	boolean turnDecided = false;
	private WeaponContainer weap= new WeaponContainer();
	private WarriorContainer war= new WarriorContainer();
	private ArrayList<Weapon> weapons = new ArrayList<Weapon>();
	private ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	private Button[] warrButton;
	private Button[] weapButton;
	
	private String warriorName;
	public String getWarriorName() {
		return warriorName;
	}

	public void setWarriorName(String warriorName) {
		this.warriorName = warriorName;
	}

	
	


	private int j=0;
//Your Character
	private Warrior alliedCharacter = null;
	private Weapon alliedWeapon=null;
//JPanel
	private JPanel characterSelection;
	private JPanel weaponSelection;
	private JPanel nameSelection;
	private JPanel battleInterfaces;
	
	public Frame(boolean warSel, String race) {
		setSize ( 900, 600 );
		setLocationRelativeTo ( null ); //centering the frame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Races Game");
		setResizable(false);
		initComponent();
		
		if (warSel==false) {
		characterSelection.setVisible(true);
		weaponSelection.setVisible(false);
		}
		else {
			add(weaponSelection);
			//warrior
			for (Warrior w :warriors) {
				if (w.getRace()==race) {
					alliedCharacter= new Warrior();
					alliedCharacter.setAgility(w.getAgility());
					alliedCharacter.setId(w.getId());
					alliedCharacter.setName(w.getName());
					alliedCharacter.setRace(w.getRace());
					alliedCharacter.setImage(w.getImage());
					alliedCharacter.setHp(w.getHp());
					alliedCharacter.setMaxHP(w.getHp());
					alliedCharacter.setStrength(w.getStrength());
					alliedCharacter.setDefense(w.getDefense());
					alliedCharacter.setAgility(w.getAgility());
					alliedCharacter.setSpeed(w.getSpeed());
					alliedCharacter.setWeapon(w.getWeapon());
					alliedCharacter.setPoints(w.getPoints());

				}
			}
			//weapons
			int i =0;
				for (Weapon w : weapons){
					weapButton=new Button[weapons.size()];
					BufferedImage image=w.getImage();
					System.out.println(w.getName());
					image=resize(image,200,200);
					weapButton[i]=new Button(new ImageIcon(image),i);
					weapButton[i].setOpaque(false);
				    weapButton[i].setContentAreaFilled(false);
				    weapButton[i].setBorderPainted(true);
				    weapButton[i].setBorder(BorderFactory.createLineBorder(Color.black));
				    setWeaponListener(i);
					if (w.getRace().contains(race)) {
						System.out.println(w.getRace());	
					weaponSelection.add(weapButton[i]);				
					
					
				}
				i++;
			}
			characterSelection.setVisible(false);
			weaponSelection.setVisible(false);
			weaponSelection.setVisible(true);
		}
		setVisible(true);
	}
	
	public void initComponent() {
		//warrior/weapon from database
		weap.setWeapons(weapons);
		war.setWarriors(warriors);
		warrButton=new Button[warriors.size()];
	//Character selection panel
		BufferedImage background;
		try {
			background = ImageIO.read(new File("Images/CharacterImages/background3.jpg"));
			characterSelection=new ImageComponent(background);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		
		characterSelection.setLayout(new GridLayout(1,3));
		int i=0;
		//adding images
		for (Warrior w : warriors){
			
				
				BufferedImage image=w.getImage();
				image=resize(image,300,563);
				
				//JLabel pic = new JLabel(new ImageIcon(background));
				//characterSelection.add(pic);
		        warrButton[i]=new Button(new ImageIcon(image),i);
		        warrButton[i].setOpaque(false);
		        warrButton[i].setContentAreaFilled(false);
		        warrButton[i].setBorderPainted(true);
		        warrButton[i].setBorder(BorderFactory.createLineBorder(Color.black));
		  
				characterSelection.add(warrButton[i]);	
			
				i++;
			
		}
		//when the images are clicked
		setCharacterListener();
		characterSelection.setVisible(false);
		add(characterSelection);
		
	//weapon selection panel
		try {
			background = ImageIO.read(new File("Images/CharacterImages/background2.jpg"));
			weaponSelection=new ImageComponent(background);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		weaponSelection.setLayout(new GridLayout(3,3));
		
	
		
	
	
	}
	
//resize images
	public static BufferedImage resize(BufferedImage img, int newW, int newH) { 
	    Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	    BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = dimg.createGraphics();
	    g2d.drawImage(tmp, 0, 0, null);
	    g2d.dispose();

	    return dimg;
	}  
//Listeners
public void setCharacterListener() {
		//botones bien
		j=0;
		for (j=0;j<warriors.size();j++) {
		warrButton[j].addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Button b = (Button) arg0.getSource();
				
						Warrior model=warriors.get(b.getId());
						alliedCharacter= new Warrior();
						alliedCharacter.setAgility(model.getAgility());
						alliedCharacter.setId(model.getId());
						alliedCharacter.setName(model.getName());
						alliedCharacter.setRace(model.getRace());
						alliedCharacter.setImage(model.getImage());
						alliedCharacter.setHp(model.getHp());
						alliedCharacter.setMaxHP(model.getHp());
						alliedCharacter.setStrength(model.getStrength());
						alliedCharacter.setDefense(model.getDefense());
						alliedCharacter.setAgility(model.getAgility());
						alliedCharacter.setSpeed(model.getSpeed());
						alliedCharacter.setWeapon(model.getWeapon());
						alliedCharacter.setPoints(model.getPoints());

						
						System.out.println(alliedCharacter);
						characterSelection.setVisible(false);
						add(weaponSelection);
						//weapons
						int i =0;
							for (Weapon w : weapons){
								weapButton=new Button[weapons.size()];
								BufferedImage image=w.getImage();
								System.out.println(w.getName());
								image=resize(image,200,200);
								weapButton[i]=new Button(new ImageIcon(image),i);
								weapButton[i].setOpaque(false);
							    weapButton[i].setContentAreaFilled(false);
							    weapButton[i].setBorderPainted(true);
							    weapButton[i].setBorder(BorderFactory.createLineBorder(Color.black));
							    setWeaponListener(i);
								if (w.getRace().contains(warriors.get(b.getId()).getRace())) {
									System.out.println(w.getRace());	
								weaponSelection.add(weapButton[i]);				
								
								
							}
							i++;
						}
							System.out.println(weapons);
						weaponSelection.setVisible(true);
							
					}
				}
			);
		
		}
	}
		
		
public void setWeaponListener(int i) {

		weapButton[i].addActionListener(
						new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent arg0) {
								System.out.println("e"+alliedCharacter);
								System.out.println(i);
								alliedWeapon=weapons.get(i);
								alliedCharacter.setWeapon(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								//Name Selection Panel
								ImageComponent namewarwepP;
								try {
								BufferedImage background = ImageIO.read(new File("Images/CharacterImages/background2.jpg"));
								namewarwepP= new ImageComponent(background);
								
								JPanel warwepP= new JPanel();
								JPanel warriorP= new JPanel();
								JPanel weaponP= new JPanel();
								JLabel chooseName=new JLabel("Enter your name:");
								JButton ok=new JButton("Ok");
								nameSelection=new JPanel();
								JTextField selectedName=new JTextField(40);
								ImageComponent warriorImage=new ImageComponent(alliedCharacter.getImage());						
								ImageComponent weaponImage = new ImageComponent(alliedWeapon.getImage());
								//Image Size
								warriorImage.setPreferredSize(new Dimension(200,400));
								warriorImage.setMinimumSize(new Dimension(200,400));
								weaponImage.setPreferredSize(new Dimension(200,200));
								weaponImage.setMinimumSize(new Dimension(200,200));
								//Panel Layout
								nameSelection.setLayout(new BoxLayout(nameSelection,BoxLayout.X_AXIS));
								warwepP.setLayout(new BoxLayout(warwepP, BoxLayout.X_AXIS));
								namewarwepP.setLayout(new BoxLayout(namewarwepP, BoxLayout.Y_AXIS));
								//Panel Size
								selectedName.setPreferredSize(new Dimension(100,30));
								chooseName.setPreferredSize(new Dimension(230,30));
								selectedName.setMaximumSize(new Dimension(100,30));
								chooseName.setMaximumSize(new Dimension(230,30));
								warriorP.setPreferredSize(new Dimension(200,400));
								warwepP.setPreferredSize(new Dimension(400,800));
								weaponP.setPreferredSize(new Dimension(200,200));
								//adding assets
								namewarwepP.add(nameSelection);
								nameSelection.add(chooseName);
								nameSelection.add(selectedName);
								nameSelection.add(ok);
								warriorP.add(warriorImage);
								weaponP.add(weaponImage);
								warwepP.add(warriorP);
								warwepP.add(weaponP);
								namewarwepP.add(warwepP);
								//setting the panels visible
								warriorP.setVisible(true);
								weaponP.setVisible(true);
								nameSelection.setVisible(true);
								warwepP.setVisible(true);
								namewarwepP.setVisible(true);
								//Set opaque
								warriorP.setOpaque(false);
								weaponP.setOpaque(false);
								nameSelection.setOpaque(false);
								warwepP.setOpaque(false);
								add(namewarwepP);
								ok.addActionListener(new ActionListener() {
									
									@Override
									public void actionPerformed(ActionEvent arg0) {
										setDefaultCloseOperation(EXIT_ON_CLOSE);
										warriorName=selectedName.getText();
										//Insertar BBDD
									
										try {
											Connection con=DriverManager.getConnection(url, user, password);
											con = DriverManager.getConnection(url, user, password);
											 Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
								                ResultSet rs = st.executeQuery("select * from players");
								                rs = st.getResultSet();

								                rs.moveToInsertRow();
								                rs.updateString(2, warriorName);
								                rs.insertRow();


								                rs = st.executeQuery("select * from players");
								                rs = st.getResultSet();
								                rs.last();
								                playerID = rs.getInt(1);
								                System.out.println("dentro");
										setDefaultCloseOperation(EXIT_ON_CLOSE);
										warriorName=selectedName.getText();
										} catch (SQLException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										namewarwepP.setVisible(false);
										Warrior enemy=enemyGeneration();
										//Battle Starter
										System.out.println(getAlliedCharacter());
										System.out.println("soy el enemigo"+enemy);
										BattleInterfaces( getAlliedCharacter(), enemy) ;
									
										
									}
								});
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								
							}
						}
						);
				
		}

public Warrior getAlliedCharacter() {
	return alliedCharacter;
}

public void setAlliedCharacter(Warrior alliedCharacter) {
	this.alliedCharacter = alliedCharacter;
}

//Battle interface
//Assignation of warriors

public void  BattleInterfaces(Warrior ally, Warrior enemy)  {
	
		allyHP= ally.getHp();
		enemyHP = enemy.getHp();
		this.localAlly=ally;
		this.localEnemy=enemy;
		this.allyHP=ally.getHp();
		this.enemyHP=enemy.getHp();
		
		//Instantiation of visual elements
		optionPanel = new JPanel();
		battlePanel = new JPanel();
		playerPanel = new JPanel();
		enemyPanel = new JPanel();
		playPanel = new JPanel();
		
		//Main panel buttons
		JButton character = new JButton("Choose Character");
		JButton weapon = new JButton("Choose Weapon");
		JButton ranking = new JButton("Ranking");
		
		optionPanel.add(character);
		optionPanel.add(weapon);
		optionPanel.add(ranking);
		
		
		
		//Icons
		BufferedImage allyIcon = ally.getImage();
		BufferedImage enemyIcon = enemy.getImage();
		BufferedImage allyHand = ally.getWeapon().getImage();
		BufferedImage enemyHand = enemy.getWeapon().getImage();
		JPanel allyIconPanel  = new ImageComponent(allyIcon);
		JPanel enemyIconPanel  = new ImageComponent(enemyIcon);
		JPanel allyHandPanel  = new ImageComponent(allyHand);
		JPanel enemyHandPanel  = new ImageComponent(enemyHand);

		//Size setting
		allyIconPanel.setPreferredSize(new Dimension(300,300));
		enemyIconPanel.setPreferredSize(new Dimension(300,300));
		allyHandPanel.setPreferredSize(new Dimension(30,30));
		enemyHandPanel.setPreferredSize(new Dimension(30,30));
		 
		//Creating and adding warrior panels
		playerHBPanel = new JPanel();
		playerHPBar = healthBar(ally);
		playerHBPanel.add(playerHPBar);
		playerHBPanel.setSize(new Dimension(210,20));
		
		enemyHBPanel = new JPanel();
		enemyHPBar = healthBar(enemy);
		enemyHBPanel.add(enemyHPBar);
		enemyHBPanel.setSize(new Dimension(210,20));
		
		JPanel allyStats = populateStatsPanel(ally);
		JPanel enemyStats = populateStatsPanel(enemy);
		
		playerPanel.add(playerHBPanel);
		playerPanel.add(allyIconPanel);
		playerPanel.add(allyStats);
		playerPanel.setLayout(new BoxLayout(playerPanel,BoxLayout.PAGE_AXIS));
		
		enemyPanel.add(enemyHBPanel);
		enemyPanel.add(enemyIconPanel);
		enemyPanel.add(enemyStats);
		enemyPanel.setLayout(new BoxLayout(enemyPanel, BoxLayout.PAGE_AXIS));
		
		battlePanel.add(playerPanel);
		battlePanel.add(enemyPanel);
		battlePanel.setLayout(new BoxLayout(battlePanel, BoxLayout.LINE_AXIS));
		
		//Fighting panel elements
		attack = new JButton("Attack");
		fight = new JButton("Fight");
		clearConsole = new JButton("Clear Console");
		
		console= new JTextArea(12,60);
		scroll = new JScrollPane(console,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		attackPanel = new JPanel();
		attackPanel.add(attack);
		attackPanel.setVisible(false);
		playPanel.add(attackPanel, BorderLayout.WEST);
		playPanel.add(fight, BorderLayout.CENTER);
		playPanel.add(clearConsole, BorderLayout.EAST);
		playPanel.add(scroll, BorderLayout.SOUTH);

//ACTION LISTENERS		
		//Action Listener to start battle with "Fight" button
		fight.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//Battle aides
				
				//Stat setting
				ally.setHp(allyHP);
				enemy.setHp(enemyHP);
				ally.setSpeed(ally.getSpeed()+ally.getWeapon().getSpeed());
				ally.setStrength(ally.getStrength()+ally.getWeapon().getAttack());
				enemy.setSpeed(enemy.getSpeed()+enemy.getWeapon().getSpeed());
				enemy.setStrength(enemy.getStrength()+enemy.getWeapon().getAttack());
				
				//Choosing first player
				
				//Setting warrior HP
				
				//Fight
				fight(ally, enemy);
					
				attackPanel.setVisible(true);
				fight.setVisible(false);

			}
		});
		
		//Add Action Listener to "Attack" button
		
		attack.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {				
				attack(enemy, ally);
				updateHealth(enemy, enemyHPBar);
				playerTurn = playerTurn + 1;
				fight(ally, enemy);
			}
			
		});
		
		clearConsole.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				console.setText("");
			}
		});
		
		//Ranking button		
		ranking.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				//RANKING
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection(url, user, password);
					ArrayList<String> ranking= new ArrayList<String>();
					PreparedStatement pst = con.prepareStatement("select * from players");
					ResultSet rs = pst.executeQuery();
					String[] line = new String[10];
					String p;
					while(rs.next())
						ranking.add(rs.getString(2));
					
					//SHOW TOP 10
					pst = con.prepareStatement("select * from ranking order by player_points desc");
					rs = pst.executeQuery();
					
					int ranking_num = 1;
					
					while(rs.next() && ranking_num < 10) {
						
						String name = ranking.get(rs.getInt(1)-1);
						
						p=ranking_num+" "+name+" "+rs.getInt(2)+" "+ warriors.get(rs.getInt(3)-1).getName();
						line[ranking_num-1]=p;
						ranking_num += 1;
					}
					JList list = new JList(line);
					JOptionPane.showMessageDialog(rootPane, list,  "Ranking", JOptionPane.INFORMATION_MESSAGE);

				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}catch (SQLException e) {
					e.printStackTrace();
				}				
		}
	});
		
		
		//Add panels to main frame and set main configurations
		this.add(optionPanel, BorderLayout.NORTH);
		this.add(battlePanel, BorderLayout.CENTER);
		this.add(playPanel,BorderLayout.SOUTH);
		this.setSize(700,700);
		this.setVisible(true);
		
		};
		

//MAIN FIGHT METHOD	
		
	public void fight(Warrior player, Warrior enemy) {		
		
		//Set initial turn
		if (turnDecided == false) {
			playerTurn = getFirstTurn(player, enemy);
			turnDecided = true;
		}
			
		
		//Main fight
		
		while (player.getHp() > 0 && enemy.getHp() > 0) {
			if (playerTurn % 2 == 0) {
				fightText=(warriorName + "'s turn: \n");
				console.append(fightText);
				break;
			}
			else {
				fightText=("Opponent's turn: \n");
				console.append(fightText);
				attack(player, enemy);
				updateHealth(player, playerHPBar);
				playerTurn = playerTurn + 1;
			}
				
		}
		if (localAlly.getHp()<=0) {
			fightText = localAlly.getName()+"'s health points have dropped to zero!";
			console.append(fightText);
			deathMenu();
		} else if (localEnemy.getHp()<=0) {
			fightText = localEnemy.getName()+"'s health points have dropped to zero!";
			console.append(fightText);
			deathMenu();
		} 
	}
	

//CHOOSING FIRST TURN METHOD
	public int getFirstTurn(Warrior player, Warrior enemy) {
		Random rn = new Random();
		
		if (player.getSpeed() < enemy.getSpeed())
			return 1;
		else if (player.getSpeed () > enemy.getSpeed())
			return 0;
		else if (player.getAgility () < enemy.getAgility())
			return 1;
		else if (player.getAgility() > enemy.getAgility())
			return 0;
		
		return rn.nextInt(2);
	}
	
//ATTACK METHOD
		public void attack(Warrior defender, Warrior attacker) {
			Random rn = new Random();
			
			int accuracy = rn.nextInt(100)+1;
			if (attacker.getAgility()*10>accuracy) {
				int defense = rn.nextInt(50)+1;
				if (defender.getAgility()>defense) {
					fightText =("\t"+defender.getName()+" dodged the attack.\n\n");
					console.append(fightText);
				} else {
					int attackerDamage = attacker.getStrength()-defender.getDefense();
					defender.setHp(defender.getHp()-attackerDamage);
					fightText =("\t"+defender.getName()+" received "+attackerDamage+" points of damage.\n\n");
					console.append(fightText);
				}
			} else {
				fightText = ("\t"+attacker.getName()+" missed the attack.\n\n");
				console.append(fightText);
			}
			
			if (attacker.getSpeed() > defender.getSpeed()) {
				if ((attacker.getSpeed() - defender.getSpeed())*10 > rn.nextInt(100)+1) {
					fightText = ("\tAdditional attack!\n\n");
					console.append(fightText);
					attack(defender, attacker);
				}
			}
			
		}
	
//AFTER COMBAT METHOD
	public void deathMenu() {	
	
		
		int option=JOptionPane.showOptionDialog(rootPane, "Do you want to keep fighting?"," " , JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE,null, new Object[] {"Yes","No"}, "Yes");
		System.out.println(option);
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection(url, user, password);
				//SAVE BATTLE DATA
				if (localEnemy.getHp()<=0) {
					playerPoints+=localEnemy.getPoints()+localEnemy.getWeapon().getPoints();
				}
				
				if (option==0) {
					
					ArrayList<String> ranking= new ArrayList<String>();
					PreparedStatement pst = con.prepareStatement("select * from players");
					ResultSet rs = pst.executeQuery();
					
					
					if (localAlly.getHp()<=0) {
						localAlly.setHp(allyHP);
						localEnemy.setHp(enemyHP);
													
						String insert="insert into ranking values("+playerID+","+playerPoints+","+localAlly.getId()+");";
						System.out.println(insert);
						pst = con.prepareStatement(insert);
						pst.executeUpdate();
						
						//choose new character
						//generate new enemy
						
					}else  {
						localAlly.setHp(allyHP);
						localEnemy.setHp(enemyHP);
						localEnemy=enemyGeneration();
						fight(getAlliedCharacter(), localEnemy);
						//generate new enemy
					}
				}else {
					System.out.println("close");
					localAlly.setHp(allyHP);
					localEnemy.setHp(enemyHP);
					
					
					String insert="insert into ranking values("+playerID+","+playerPoints+","+localAlly.getId()+");";
					System.out.println(insert);
					PreparedStatement pst = con.prepareStatement(insert);
					pst.executeUpdate();
					
					super.dispose();
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			turnDecided = false;
		}

		
	
//HEALTH BAR METHODS
	
	public JProgressBar healthBar(Warrior character) {
		healthBar = new JProgressBar(0,100);
		healthBar.setUI(new BasicProgressBarUI() {
			protected Color getSelectionForeground() {return Color.BLACK;}	
		});
		healthBar.setStringPainted(true);

		healthBar.setPreferredSize(new Dimension(210,20));
		healthBar.setForeground(Color.green);
		healthBar.setValue(100);
		return healthBar;		
	}
	
	public void updateHealth(Warrior character, JProgressBar healthBar) {
		healthBar.setValue(character.getHp()*100/character.getMaxHP());
	}
	
//STAT BARS METHOD	

	public JPanel populateStatsPanel(Warrior character) {
		JPanel superpanel = new JPanel(); 
		JPanel statsPanel = new JPanel();
		BufferedImage[] images = new BufferedImage[4];
		BufferedImage strengthIcon = null, dexterityIcon = null, speedIcon = null, defenseIcon=null; ;
		try {
			strengthIcon = ImageIO.read(new File("Images/StatsImages/strength.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			dexterityIcon = ImageIO.read(new File("Images/StatsImages/dexterity.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
				speedIcon = ImageIO.read(new File("Images/StatsImages/speed.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			defenseIcon = ImageIO.read(new File("Images/StatsImages/defense.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		JPanel  strengthIconPanel = new ImageComponent(strengthIcon);
		JPanel  dexterityIconPanel = new ImageComponent(dexterityIcon);
		JPanel  speedIconPanel = new ImageComponent(speedIcon);
		JPanel  defenseIconPanel = new ImageComponent(defenseIcon);

		statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.PAGE_AXIS));
		
		strengthBar = new JProgressBar(0,11);
		strengthBar.setPreferredSize(new Dimension(180,15));
		strengthBar.setForeground(Color.red);
		strengthBar.setValue(character.getStrength()+character.getWeapon().getAttack());
		
		dexterityBar = new JProgressBar(0,11);
		dexterityBar.setPreferredSize(new Dimension(180,15));
		dexterityBar.setForeground(Color.magenta);
		dexterityBar.setValue(character.getAgility());
		
		speedBar = new JProgressBar(0,11);
		speedBar.setPreferredSize(new Dimension(180,15));
		speedBar.setForeground(Color.yellow);
		speedBar.setValue(character.getSpeed()+character.getWeapon().getSpeed());
		
		defenseBar = new JProgressBar(0,11);
		defenseBar.setPreferredSize(new Dimension(180,15));
		defenseBar.setForeground(Color.blue);
		defenseBar.setValue(character.getDefense());
		

		JPanel iconPanel = new JPanel();
		strengthIconPanel.setPreferredSize(new Dimension(15,15));
		iconPanel.add(strengthIconPanel);
		dexterityIconPanel.setPreferredSize(new Dimension(15,15));

		statsPanel.add(strengthBar);
		iconPanel.add(dexterityIconPanel);
		statsPanel.add(dexterityBar);
		speedIconPanel.setPreferredSize(new Dimension(15,15));

		iconPanel.add(speedIconPanel);
		statsPanel.add(speedBar);
		defenseIconPanel.setPreferredSize(new Dimension(15,15));

		iconPanel.add(defenseIconPanel);
		statsPanel.add(defenseBar);
		iconPanel.setLayout(new BoxLayout(iconPanel, BoxLayout.PAGE_AXIS));

		superpanel.setSize(600,600);
		superpanel.add(iconPanel);
		superpanel.add(statsPanel);

		JPanel weapon = new JPanel();
		BufferedImage object = character.getWeapon().getImage();
		JPanel objectPanel = new ImageComponent(object);
		objectPanel.setPreferredSize(new Dimension(50,50));
		weapon.add(objectPanel);
		superpanel.add(weapon,BorderLayout.EAST);
		return superpanel;
	}
	
public Warrior enemyGeneration() {
	
	//Random Enemy Generation
	System.out.println("antes"+getAlliedCharacter());
	
	Warrior enemy= new Warrior();
	System.out.println("antes"+enemy);
	Weapon enemyWeapon= new Weapon();
	int randomEnemy=(int)(Math.random()*3);
	boolean loop=true;
	Warrior model=warriors.get(randomEnemy);
	enemy= new Warrior();
	enemy.setAgility(model.getAgility());
	enemy.setId(model.getId());
	enemy.setName(model.getName());
	enemy.setRace(model.getRace());
	enemy.setImage(model.getImage());
	enemy.setHp(model.getHp());
	enemy.setMaxHP(model.getHp());
	enemy.setStrength(model.getStrength());
	enemy.setDefense(model.getDefense());
	enemy.setAgility(model.getAgility());
	enemy.setSpeed(model.getSpeed());
	enemy.setWeapon(model.getWeapon());
	enemy.setPoints(model.getPoints());

	while (loop){
		int randomWeapon=(int)(Math.random()*9);
		enemyWeapon=weapons.get(randomWeapon);
		if (enemyWeapon.getRace().contains(enemy.getRace())) {		
			enemy.setWeapon(enemyWeapon);
			loop=false;
			System.out.println(getAlliedCharacter());
			System.out.println(enemy);
			
		}
	}
	return enemy;
}

}






class Button extends JButton{
	private int id = 0;
	public Button(ImageIcon nombre, int id) {
		super(nombre);
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}

