package Characters;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Game.ImageComponent;
import Weapons.Weapon;

public class WarriorContainer {
	String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC",user="user",password="";
    String query="select w.*,r.* from warriors w join races r on w.warrior_race = r.race_id";
    private ArrayList<Warrior> warriors= new ArrayList<Warrior>();


    public ArrayList<Warrior> getWarrios() {
        return warriors;
    }

    public void setWarriors(ArrayList<Warrior> warriors) {
        //BBDD connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("no se ha podido cargar el driver");
        }

        try {
        	Connection con=DriverManager.getConnection(url, user, password);
            //STATEMENT
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            
            while(rs.next()) {
            	Warrior w = new Warrior();
            		w.setId(rs.getInt(1));
                    w.setName(rs.getString(2));
                    w.setRace(rs.getString(6));
                    w.setImage(rs.getString(3));
                    w.setHp(rs.getInt(7));
                    w.setMaxHP(rs.getInt(7));
                    w.setStrength(rs.getInt(8));
                    w.setDefense(rs.getInt(9));
                    w.setAgility(rs.getInt(10));
                    w.setSpeed(rs.getInt(11));
                    w.setPoints(rs.getInt(12));
                    warriors.add(w);
            	
            }
        }catch (SQLException e) {
        	e.printStackTrace();
            System.out.println("no se ha podido Establecer la conexion");
        }
        this.warriors = warriors;
    }
}
