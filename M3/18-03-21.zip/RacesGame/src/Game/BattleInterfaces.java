package Game;

import Characters.Warrior;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.plaf.basic.BasicProgressBarUI;

public class BattleInterfaces extends JFrame{
	JPanel allypanel,enemypanel, playpanel,battlepanel,optionpanel;
	JButton fight, clearConsole;
	JTextArea console;
	JScrollPane scroll;
	JScrollBar bar;
	JButton buttons[] = new JButton[5];
	int hp = 60;
	JProgressBar healthBar,strengthBar, dexterityBar,speedBar,defenseBar ;
	String fightText ="";
	Warrior ally=null, enemy=null;
	int allyHP=0, enemyHP=0;
	String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC";
	
	String user="user";
	String password="";
	String players="select * from players";
	
	
	public BattleInterfaces(Warrior ally, Warrior enemy)  {
		
		
		
		int allyHP= ally.getHp(), enemyHP = enemy.getHp();
		
		this.ally=ally;
		this.enemy=enemy;
		
		this.allyHP=ally.getHp();
		this.enemyHP=enemy.getHp();
		optionpanel=new JPanel();
		battlepanel =new JPanel();
		allypanel =new JPanel();
		enemypanel = new JPanel();
		playpanel = new JPanel();
		
		optionpanel.setOpaque(false);
		allypanel.setOpaque(false);
		enemypanel.setOpaque(false);
		battlepanel.setOpaque(false);
		playpanel.setOpaque(false);
		
		
		JButton character = new JButton("Choose Character");
		JButton weapon = new JButton("Choose Weapon");
		JButton ranking = new JButton("Ranking");
		optionpanel.add(character);
		optionpanel.add(weapon);
		optionpanel.add(ranking);
		
		
		 
		 Toolkit screen=Toolkit.getDefaultToolkit();
		 BufferedImage allyIcon = ally.getImage();
		 BufferedImage enemyIcon = enemy.getImage();
		 BufferedImage allyHand = ally.getWeapon().getImage();
		 BufferedImage enemyHand = enemy.getWeapon().getImage();
		 JPanel allyIconPanel  = new ImageComponent(allyIcon);
		 JPanel enemyIconPanel  = new ImageComponent(enemyIcon);
		 JPanel allyHandPanel  = new ImageComponent(allyHand);
		 JPanel enemyHandPanel  = new ImageComponent(enemyHand);

		 allyIconPanel.setPreferredSize(new Dimension(300,300));
		 enemyIconPanel.setPreferredSize(new Dimension(300,300));
		 allyHandPanel.setPreferredSize(new Dimension(30,30));
		 enemyHandPanel.setPreferredSize(new Dimension(30,30));
		 
		
		JPanel allyHBPanel = new JPanel();
		JProgressBar AllyHealthBar=healthBar(ally);
		allyHBPanel.add(AllyHealthBar);
		allyHBPanel.setSize(new Dimension(210,20));
		
		JPanel enemyHBPanel = new JPanel();
		JProgressBar enemyHealthBar=healthBar(ally);
		enemyHBPanel.add(enemyHealthBar);
		enemyHBPanel.setSize(new Dimension(210,20));
		
		
		JPanel allyStats = statsPanel(ally);
		JPanel enemyStats = statsPanel(enemy);
		
		allypanel.add(allyHBPanel);
		allypanel.add(allyIconPanel);
		allypanel.add(allyStats);

		allypanel.setLayout(new BoxLayout(allypanel,BoxLayout.PAGE_AXIS)); 
		 
		  
		enemypanel.add(enemyHBPanel);
		enemypanel.add(enemyIconPanel);
		enemypanel.add(enemyStats);
		enemypanel.setLayout(new BoxLayout(enemypanel, BoxLayout.PAGE_AXIS));
		 
		
		battlepanel.add(allypanel);
		battlepanel.add(enemypanel);
		battlepanel.setLayout(new BoxLayout(battlepanel, BoxLayout.LINE_AXIS));
		 
		JButton attack = new JButton("Attack");

		fight = new JButton("Fight");
		
		clearConsole = new JButton("Clear Console");
		console= new JTextArea(12,60);
		scroll = new JScrollPane(console,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JPanel panelAtack = new JPanel();
		panelAtack.add(attack);
		panelAtack.setVisible(false);
		playpanel.add(panelAtack, BorderLayout.WEST);
		playpanel.add(fight, BorderLayout.CENTER);
		playpanel.add(clearConsole, BorderLayout.EAST);
		playpanel.add(scroll, BorderLayout.SOUTH); 
		
		fight.addActionListener(new ActionListener() {
			int allyID = ally.getId();
			boolean fighting = true;

			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Random rn = new Random();
				FirstDefenderAtacker setFirst;
				ally.setHp(allyHP);
				enemy.setHp(enemyHP);
				
				ally.setSpeed(ally.getSpeed()+ally.getWeapon().getSpeed());
				ally.setStrength(ally.getStrength()+ally.getWeapon().getAttack());
				enemy.setSpeed(enemy.getSpeed()+enemy.getWeapon().getSpeed());
				enemy.setStrength(enemy.getStrength()+enemy.getWeapon().getAttack());
				
				setFirst = new FirstDefenderAtacker(ally,enemy,AllyHealthBar, enemyHealthBar);
				Warrior attacker = setFirst.getAtacker();
				Warrior defender = setFirst.getDefender();
				
				JProgressBar atackerHPbar = setFirst.getAtackerHPBar();
				JProgressBar defenderHPbar = setFirst.getDefenderHPBar();
				
				int atackerMaxHP = setFirst.getAtackerMaxHP();
				int defenderMaxHP = setFirst.getDefenderMaxHP();
				
				
				fight(attacker, defender, atackerMaxHP, defenderMaxHP, atackerHPbar, defenderHPbar, ally.getId());
					
				ally.setSpeed(ally.getSpeed()-ally.getWeapon().getSpeed());
				ally.setStrength(ally.getStrength()-ally.getWeapon().getAttack());
				enemy.setSpeed(enemy.getSpeed()-enemy.getWeapon().getSpeed());
				enemy.setStrength(enemy.getStrength()-enemy.getWeapon().getAttack());
				panelAtack.setVisible(true);
				fight.setVisible(false);

			}});
		
		attack.addActionListener(new ActionListener() {
			
			
			int death = 0;
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ally.setSpeed(ally.getSpeed()+ally.getWeapon().getSpeed());
				ally.setStrength(ally.getStrength()+ally.getWeapon().getAttack());
				enemy.setSpeed(enemy.getSpeed()+enemy.getWeapon().getSpeed());
				enemy.setStrength(enemy.getStrength()+enemy.getWeapon().getAttack());
				int select;
				if (death==1) {
					fightText = ally.getName()+" died\n\n";
					console.append(fightText);
				} else if (death==2) {
					fightText = enemy.getName()+" died\n\n";
					console.append(fightText);
				}else {
					atac(ally,enemy, allyHP, enemyHP,AllyHealthBar , enemyHealthBar);
					select = getAttacker(ally, enemy);
					if (select== 1) {
						fight(ally, enemy, allyHP, enemyHP, AllyHealthBar, enemyHealthBar, ally.getId());
					}else if (select == 2){
						fight(enemy, ally, enemyHP, allyHP, enemyHealthBar, AllyHealthBar, ally.getId());
					}
					if (ally.getHp()<=0) {
						death=1;
						fightText = ally.getName()+" died\n\n";
						console.append(fightText);
						deathMenu();
					}else if (enemy.getHp()<=0) {
						death=2;
						fightText = enemy.getName()+" died\n\n";
						console.append(fightText);
						deathMenu();
					} 
				
					}
				ally.setSpeed(ally.getSpeed()-ally.getWeapon().getSpeed());
				ally.setStrength(ally.getStrength()-ally.getWeapon().getAttack());
				enemy.setSpeed(enemy.getSpeed()-enemy.getWeapon().getSpeed());
				enemy.setStrength(enemy.getStrength()-enemy.getWeapon().getAttack());
				}
		}
		);
		
		clearConsole.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String fightText="";
				console.setText(fightText);
			}
			
		});
		ranking.addActionListener(new ActionListener() {

			@Override 
			public void actionPerformed(ActionEvent arg0) {
				//RANKING
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection(url, user, password);
					ArrayList<String> ranking= new ArrayList<String>();
					PreparedStatement pst = con.prepareStatement("select * from players");
					ResultSet rs = pst.executeQuery();
					String[] line = new String[10];
					String p;
					while(rs.next())
						ranking.add(rs.getString(2));
					
					//SHOW TOP 10
					pst = con.prepareStatement("select * from ranking order by player_points desc");
					rs = pst.executeQuery();
					
					int ranking_num = 1;
					
					while(rs.next() && ranking_num < 10) {
						
						String name = ranking.get(rs.getInt(1)-1);
						
						p=ranking_num+" "+name+" "+rs.getInt(2)+" "+ rs.getInt(3);
						line[ranking_num-1]=p;
						ranking_num += 1;
					}
					JList list = new JList(line);
					JOptionPane.showMessageDialog(rootPane, list,  "Ranking", JOptionPane.INFORMATION_MESSAGE);

				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
		}
	});
		
		this.add(optionpanel, BorderLayout.NORTH);
		this.add(battlepanel, BorderLayout.CENTER);
		this.add(playpanel,BorderLayout.SOUTH);
	
		this.setSize(700,700);
		setLocationRelativeTo ( null ); //centering the frame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Races Game");
		setResizable(false);
		this.setVisible(true);
		
		};
		
	public void deathMenu() {
	
		
		int option=JOptionPane.showOptionDialog(rootPane, "Do you want to keep fighting?"," " , JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE,null, new Object[] {"Yes","No"}, "Yes");
		System.out.println(option);
		if (option==0) {
			Connection con;
			String playerName = ally.getPlayerName(); 	 //Lo que introduzca el usuario
			//PLAY AGAIN
			if (ally.getHp()<=0) {
				ally.setHp(allyHP);
				enemy.setHp(enemyHP);
				//Save points on database
			

				
				try { //esta mal puesto
					con = DriverManager.getConnection(url, user, password);
					 Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		                ResultSet rs = st.executeQuery("select * from players");
		                rs = st.getResultSet();

		                rs.moveToInsertRow();
		                rs.updateString(2, playerName);
		                rs.insertRow();


		                rs = st.executeQuery("select * from players");
		                rs = st.getResultSet();
		                rs.last();
		                int playerID = rs.getInt(1);
		                System.out.println("dentro");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
               
      
				//choose new character
				//generate new enemy
			}else if (enemy.getHp()<=0) {

				try {
				con = DriverManager.getConnection(url, user, password);
				 Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
	                ResultSet rs = st.executeQuery("select * from players");
	                rs = st.getResultSet();

	                rs.moveToInsertRow();
	                rs.updateString(2, playerName);
	                rs.insertRow();


	                rs = st.executeQuery("select * from players");
	                rs = st.getResultSet();
	                rs.last();
	                int playerID = rs.getInt(1);
	                System.out.println("dentro");
	                
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
          
 
				//set ally Hp 100%
				//set enemy Hp 100%
				//generate new enemy
				
				
			}
		}else {
			System.out.println("close");
			ally.setHp(allyHP);
			enemy.setHp(enemyHP);
			
			//save points on database
			
			super.dispose();
		}
		
		
		
		
		
	}
	public void fight(Warrior atac, Warrior def, int atacHP, int defHP, JProgressBar atacHealthBar, JProgressBar defHealthBar, int allyId) {
		Random rn = new Random();
		boolean fighting = true;
		Warrior attacker = atac, defender  = def;
		int atackerMaxHP = atacHP, defenderMaxHP=defHP;
		JProgressBar atackerHPBar = atacHealthBar, defenderHPBar = defHealthBar;
		int accuracity,defense, atackDamage;
		while (attacker.getHp()>0 && defender.getHp()>0) {
			if (attacker.getId()==allyId) {
				fightText=(attacker.getName()+" torn: \n");
				console.append(fightText);
				break;
			} else if (fighting) {
				 
				fightText=(attacker.getName()+" torn: \n");
				console.append(fightText);
				accuracity = rn.nextInt(100)+1;
				if (attacker.getAgility()*10>accuracity) {
					defense = rn.nextInt(50)+1;
					if (defender.getAgility()>defense) {
						fightText =("\t"+defender.getName()+" dodge the attack.\n\n");
						console.append(fightText);
					}else {
						atackDamage = attacker.getStrength()-defender.getDefense();
						defender.setHp(defender.getHp()-atackDamage);
						fightText =("\t"+defender.getName()+" has recibed "+atackDamage+" points of damage.\n\n");
						console.append(fightText);
						System.out.println(defenderMaxHP);
						UpdateHealth(defender,defenderMaxHP, defHealthBar);
					}
				}else {
					fightText =("\t"+attacker.getName()+" miss the attack.\n\n");
					console.append(fightText);

				}
				
				fighting=false;
			} else if (fighting==false){
				int number = rn.nextInt(100)+1;
				Warrior transition;
				int transitionMaxHP;
				JProgressBar transitionBar;
				if(attacker.getSpeed()<=defender.getSpeed()) {
					//Change defensor to attacker
					transition=defender; transitionMaxHP=defenderMaxHP; transitionBar = defHealthBar;
					defender=attacker; defenderMaxHP=atackerMaxHP; defHealthBar = atacHealthBar;
					attacker=transition; atackerMaxHP=transitionMaxHP; atacHealthBar = transitionBar;
				} else if(((attacker.getSpeed()-defender.getSpeed())*10)<number){
					//Change defensor to attacker.
					transition=defender;  transitionMaxHP=defenderMaxHP; transitionBar = defHealthBar;
					defender=attacker; defenderMaxHP=atackerMaxHP; defHealthBar = atacHealthBar;
					attacker=transition; atackerMaxHP=transitionMaxHP; atacHealthBar = transitionBar;
				}
				fighting = true; 
				}
			}
	}
	public void atac(Warrior atac, Warrior def, int atacHP, int defHP, JProgressBar atacHealthBar, JProgressBar defHealthBar) {
		Random rn = new Random();
		boolean fighting = true;
		Warrior attacker = atac, defender  = def;
		int atackerMaxHP = atacHP, defenderMaxHP=defHP;
		JProgressBar atackerHPBar = atacHealthBar, defenderHPBar = defHealthBar;
		int accuracity,defense, atackDamage;
		accuracity = rn.nextInt(100)+1;
		if (attacker.getAgility()*10>accuracity) {
			defense = rn.nextInt(50)+1;
			if (defender.getAgility()>defense) {
				fightText =("\t"+defender.getName()+" dodge the attack.\n\n");
				console.append(fightText);
			}else {
				atackDamage = attacker.getStrength()-defender.getDefense();
				defender.setHp(defender.getHp()-atackDamage);
				fightText =("\t"+defender.getName()+" has recibed "+atackDamage+" points of damage.\n\n");
				console.append(fightText);
				UpdateHealth(defender,defenderMaxHP, defenderHPBar);
			}
		}else {
			fightText =("\t"+attacker.getName()+" miss the attack.\n\n");
			console.append(fightText);

		}
	}
	public int getAttacker(Warrior ally, Warrior enemy) {
		Random rn = new Random();
		int number = rn.nextInt(100)+1;
		if(ally.getSpeed()<=enemy.getSpeed()) {
			return 2;
		} else if(((ally.getSpeed()-enemy.getSpeed())*10)<number){
			return 2;
		}else {
			return 1;
		}
	}
	
	public JProgressBar healthBar(Warrior character) {
		healthBar = new JProgressBar(0,100);
		healthBar.setUI(new BasicProgressBarUI() {
			protected Color getSelectionForeground() {return Color.BLACK;}	

		});
		healthBar.setStringPainted(true);

		healthBar.setPreferredSize(new Dimension(210,20));
		healthBar.setForeground(Color.green);
		healthBar.setValue(100);
		return healthBar;
		
	}
	
	public  void UpdateHealth(Warrior character, int maxhp, JProgressBar healthBar )	{
		healthBar.setValue(character.getHp()*100/maxhp);
	}
	
	
	public JPanel statsPanel(Warrior character) {
		JPanel superpanel = new JPanel(); 
		JPanel statsPanel = new JPanel();
		superpanel.setOpaque(false);
		BufferedImage strengthIcon = null, dexterityIcon = null, speedIcon = null, defenseIcon=null; ;
		try {
			strengthIcon = ImageIO.read(new File("Images/StatsImages/strength.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			dexterityIcon = ImageIO.read(new File("Images/StatsImages/dexterity.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
				speedIcon = ImageIO.read(new File("Images/StatsImages/speed.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			defenseIcon = ImageIO.read(new File("Images/StatsImages/defense.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JPanel  strengthIconPanel = new ImageComponent(strengthIcon);
		JPanel  dexterityIconPanel = new ImageComponent(dexterityIcon);
		JPanel  speedIconPanel = new ImageComponent(speedIcon);
		JPanel  defenseIconPanel = new ImageComponent(defenseIcon);

		statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.PAGE_AXIS));
		
		strengthBar = new JProgressBar(0,11);
		strengthBar.setPreferredSize(new Dimension(180,15));
		strengthBar.setForeground(Color.red);
		strengthBar.setValue(character.getStrength()+character.getWeapon().getAttack());
		
		dexterityBar = new JProgressBar(0,11);
		dexterityBar.setPreferredSize(new Dimension(180,15));
		dexterityBar.setForeground(Color.magenta);
		dexterityBar.setValue(character.getAgility());
		
		speedBar = new JProgressBar(0,11);
		speedBar.setPreferredSize(new Dimension(180,15));
		speedBar.setForeground(Color.yellow);
		speedBar.setValue(character.getSpeed()+character.getWeapon().getSpeed());
		
		defenseBar = new JProgressBar(0,11);
		defenseBar.setPreferredSize(new Dimension(180,15));
		defenseBar.setForeground(Color.blue);
		defenseBar.setValue(character.getDefense());
		

		JPanel iconPanel = new JPanel();
		strengthIconPanel.setPreferredSize(new Dimension(15,15));
		iconPanel.add(strengthIconPanel);
		dexterityIconPanel.setPreferredSize(new Dimension(15,15));

		statsPanel.add(strengthBar);
		iconPanel.add(dexterityIconPanel);
		statsPanel.add(dexterityBar);
		speedIconPanel.setPreferredSize(new Dimension(15,15));

		iconPanel.add(speedIconPanel);
		statsPanel.add(speedBar);
		defenseIconPanel.setPreferredSize(new Dimension(15,15));

		iconPanel.add(defenseIconPanel);
		statsPanel.add(defenseBar);
		iconPanel.setLayout(new BoxLayout(iconPanel, BoxLayout.PAGE_AXIS));

		superpanel.setSize(600,600);
		superpanel.add(iconPanel);
		superpanel.add(statsPanel);

		JPanel weapon = new JPanel();
		BufferedImage object = character.getWeapon().getImage();
		JPanel objectPanel = new ImageComponent(object);
		objectPanel.setPreferredSize(new Dimension(50,50));
		weapon.add(objectPanel);
		superpanel.add(weapon,BorderLayout.EAST);
		return superpanel;
		
	}
	public static BufferedImage resize(BufferedImage img, int newW, int newH) { 
        Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
        BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = dimg.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();

        return dimg;

}
	
}
class FirstDefenderAtacker{
	Random rn = new Random();
	Warrior attacker, defender;
	int attackerMaxHP, defenderMaxHP;
	JProgressBar atackerHPbar, defenderHPbar, AllyHealthBar, enemyHealthBar;

    public FirstDefenderAtacker(Warrior ally, Warrior enemy, JProgressBar AllyHealthBar, JProgressBar enemyHealthBar) {
    	this.AllyHealthBar = AllyHealthBar;
    	this.enemyHealthBar=enemyHealthBar;
    	if (ally.getSpeed()>enemy.getSpeed()) {
			this.attacker=ally;
			this.attackerMaxHP=ally.getHp();
			this.atackerHPbar=AllyHealthBar;
			this.defender=enemy;
			this.defenderMaxHP=enemy.getHp();
			this.defenderHPbar=enemyHealthBar;
		} else if (ally.getSpeed()<enemy.getSpeed()) {
			this.attacker=enemy;
			this.attackerMaxHP=enemy.getHp();
			this.atackerHPbar=enemyHealthBar;
			this.defender=ally;
			this.defenderMaxHP=ally.getHp();
			this.defenderHPbar=AllyHealthBar;

		}else if (ally.getAgility()>enemy.getAgility()) {
			this.attacker=ally;
			this.attackerMaxHP=ally.getHp();
			this.atackerHPbar=AllyHealthBar;

			this.defender=enemy;
			this.defenderMaxHP=enemy.getHp();
			this.defenderHPbar=enemyHealthBar;

		}else if (ally.getAgility()<enemy.getAgility()) {
			this.attacker=enemy;
			this.attackerMaxHP=enemy.getHp();
			this.atackerHPbar=enemyHealthBar;

			this.defender=ally;
			this.defenderMaxHP=ally.getHp();
			this.defenderHPbar=AllyHealthBar;

		} else {
			int chooseFirst=rn.nextInt(2)+1;
			if (chooseFirst==1) {
				this.attacker=ally;
				this.attackerMaxHP=ally.getHp();
				this.atackerHPbar=AllyHealthBar;

				this.defender=enemy;
				this.defenderMaxHP = enemy.getHp();
				this.defenderHPbar=enemyHealthBar;

			} else {
				this.attacker=enemy;
				this.attackerMaxHP=enemy.getHp();
				this.atackerHPbar=enemyHealthBar;

				this.defender=ally;
				this.defenderMaxHP=ally.getHp();
				this.defenderHPbar=AllyHealthBar;

			}
		}
    }

    public Warrior getAtacker() {
        return attacker;
    }

    public Warrior getDefender() {
        return defender;
    }
    public int getAtackerMaxHP() {
    	return attackerMaxHP;
    }
    public int getDefenderMaxHP() {
    	return defenderMaxHP;
    }
    public JProgressBar getAtackerHPBar() {
    	return atackerHPbar;
    }
    public JProgressBar getDefenderHPBar() {
    	return defenderHPbar;
    }
}
