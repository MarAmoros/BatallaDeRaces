package Game;
import Characters.*;
import Weapons.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import javax.imageio.*;
import javax.swing.*;
import Weapons.*;

public class Frame extends JFrame {
	//BBDD
	 String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC",user="user",password="";
	 //boolean for warrior and weapon selection
	 boolean warSel=false;
	 boolean weapSel=false;
//Weapons and warriors
	
	private WeaponContainer weap= new WeaponContainer();
	private WarriorContainer war= new WarriorContainer();
	private ArrayList<Weapon> weapons = new ArrayList<Weapon>();
	private ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	private Button[] warrButton;
	private Button[] weapButton;
	
	private String warriorName;
	public String getWarriorName() {
		return warriorName;
	}

	public void setWarriorName(String warriorName) {
		this.warriorName = warriorName;
	}

	
	public boolean isWarSel() {
		return warSel;
	}

	public void setWarSel(boolean warSel) {
		this.warSel = warSel;
	}

	public boolean isWeapSel() {
		return weapSel;
	}

	public void setWeapSel(boolean weapSel) {
		this.weapSel = weapSel;
	}


	private int j=0;
//Your Character
	private Warrior alliedCharacter = null;
	private Weapon alliedWeapon=null;
//JPanel
	private JPanel characterSelection;
	private JPanel weaponSelection;
	private JPanel nameSelection;

	
	public Frame() {
		setSize ( 900, 600 );
		setLocationRelativeTo ( null ); //centering the frame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Races Game");
		setResizable(false);
		initComponent();
		
		if (warSel) {
		characterSelection.setVisible(true);
		weaponSelection.setVisible(false);
		}
		else {
			characterSelection.setVisible(false);
			weaponSelection.setVisible(true);
		}
		setVisible(true);
	}
	
	public void initComponent() {
		//warrior/weapon from database
		weap.setWeapons(weapons);
		war.setWarriors(warriors);
		warrButton=new Button[warriors.size()];
	//Character selection panel
		BufferedImage background;
		try {
			background = ImageIO.read(new File("Images/CharacterImages/background3.jpg"));
			characterSelection=new ImageComponent(background);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		
		characterSelection.setLayout(new GridLayout(1,3));
		int i=0;
		//adding images
		for (Warrior w : warriors){
			
				
				BufferedImage image=w.getImage();
				image=resize(image,300,563);
				
				//JLabel pic = new JLabel(new ImageIcon(background));
				//characterSelection.add(pic);
		        warrButton[i]=new Button(new ImageIcon(image),i);
		        warrButton[i].setOpaque(false);
		        warrButton[i].setContentAreaFilled(false);
		        warrButton[i].setBorderPainted(true);
		        warrButton[i].setBorder(BorderFactory.createLineBorder(Color.black));
		  
				characterSelection.add(warrButton[i]);	
			
				i++;
			
		}
		//when the images are clicked
		setCharacterListener();
		characterSelection.setVisible(false);
		add(characterSelection);
		
	//weapon selection panel
		try {
			background = ImageIO.read(new File("Images/CharacterImages/background2.jpg"));
			weaponSelection=new ImageComponent(background);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		weaponSelection.setLayout(new GridLayout(3,3));
		
	
	
	
	
	}
	
//resize images
	public static BufferedImage resize(BufferedImage img, int newW, int newH) { 
	    Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	    BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = dimg.createGraphics();
	    g2d.drawImage(tmp, 0, 0, null);
	    g2d.dispose();

	    return dimg;
	}  
//Liteners
public void setCharacterListener() {
		//botones bien
		j=0;
		for (j=0;j<warriors.size();j++) {
		warrButton[j].addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Button b = (Button) arg0.getSource();
						
						Warrior model=warriors.get(b.getId());
						//alliedCharacter= new Warrior();
						alliedCharacter.setAgility(model.getAgility());
						alliedCharacter.setId(model.getId());
						alliedCharacter.setName(model.getName());
						alliedCharacter.setRace(model.getRace());
						alliedCharacter.setPhoto(model.getImage());
						alliedCharacter.setHp(model.getHp());
						alliedCharacter.setStrength(model.getStrength());
						alliedCharacter.setDefense(model.getDefense());
						alliedCharacter.setAgility(model.getAgility());
						alliedCharacter.setSpeed(model.getSpeed());
						alliedCharacter.setWeapon(model.getWeapon());
						alliedCharacter.setPoints(model.getPoints());
						alliedCharacter.setAllied(true);
						
						System.out.println(alliedCharacter);
						characterSelection.setVisible(false);
						add(weaponSelection);
						//weapons
						int i =0;
							for (Weapon w : weapons){
								weapButton=new Button[weapons.size()];
								BufferedImage image=w.getImage();
								System.out.println(w.getName());
								image=resize(image,200,200);
								weapButton[i]=new Button(new ImageIcon(image),i);
								weapButton[i].setOpaque(false);
							    weapButton[i].setContentAreaFilled(false);
							    weapButton[i].setBorderPainted(true);
							    weapButton[i].setBorder(BorderFactory.createLineBorder(Color.black));
							    setWeaponListener(i);
								if (w.getRace().contains(warriors.get(b.getId()).getRace())) {
									System.out.println(w.getRace());	
								weaponSelection.add(weapButton[i]);				
								
								
							}
							i++;
						}
							System.out.println(weapons);
						weaponSelection.setVisible(true);
							
					}
				}
			);
		
		}
	}
		
		
public void setWeaponListener(int i) {

		weapButton[i].addActionListener(
						new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent arg0) {
								System.out.println(i);
								alliedWeapon=weapons.get(i);
								alliedCharacter.setWeapon(alliedWeapon);
								System.out.println(alliedCharacter);
								weaponSelection.setVisible(false);
								//Name Selection Panel
								ImageComponent namewarwepP;
								try {
								BufferedImage background = ImageIO.read(new File("Images/CharacterImages/background2.jpg"));
								namewarwepP= new ImageComponent(background);
								
								JPanel warwepP= new JPanel();
								JPanel warriorP= new JPanel();
								JPanel weaponP= new JPanel();
								JLabel chooseName=new JLabel("Choose this characters' name:");
								JButton ok=new JButton("Ok");
								nameSelection=new JPanel();
								JTextField selectedName=new JTextField(40);
								ImageComponent warriorImage=new ImageComponent(alliedCharacter.getImage());						
								ImageComponent weaponImage = new ImageComponent(alliedWeapon.getImage());
								//Image Size
								warriorImage.setPreferredSize(new Dimension(200,400));
								warriorImage.setMinimumSize(new Dimension(200,400));
								weaponImage.setPreferredSize(new Dimension(200,200));
								weaponImage.setMinimumSize(new Dimension(200,200));
								//Panel Layout
								nameSelection.setLayout(new BoxLayout(nameSelection,BoxLayout.X_AXIS));
								warwepP.setLayout(new BoxLayout(warwepP, BoxLayout.X_AXIS));
								namewarwepP.setLayout(new BoxLayout(namewarwepP, BoxLayout.Y_AXIS));
								//Panel Size
								selectedName.setPreferredSize(new Dimension(100,30));
								chooseName.setPreferredSize(new Dimension(230,30));
								selectedName.setMaximumSize(new Dimension(100,30));
								chooseName.setMaximumSize(new Dimension(230,30));
								warriorP.setPreferredSize(new Dimension(200,400));
								warwepP.setPreferredSize(new Dimension(400,800));
								weaponP.setPreferredSize(new Dimension(200,200));
								//adding assets
								namewarwepP.add(nameSelection);
								nameSelection.add(chooseName);
								nameSelection.add(selectedName);
								nameSelection.add(ok);
								warriorP.add(warriorImage);
								weaponP.add(weaponImage);
								warwepP.add(warriorP);
								warwepP.add(weaponP);
								namewarwepP.add(warwepP);
								//setting the panels visible
								warriorP.setVisible(true);
								weaponP.setVisible(true);
								nameSelection.setVisible(true);
								warwepP.setVisible(true);
								namewarwepP.setVisible(true);
								//Set opaque
								warriorP.setOpaque(false);
								weaponP.setOpaque(false);
								nameSelection.setOpaque(false);
								warwepP.setOpaque(false);
								add(namewarwepP);
								ok.addActionListener(new ActionListener() {
									
									@Override
									public void actionPerformed(ActionEvent arg0) {
										setDefaultCloseOperation(EXIT_ON_CLOSE);
										warriorName=selectedName.getText();
										alliedCharacter.setPlayerName(warriorName);
										//Insertar BBDD
									
										try {
											Connection con=DriverManager.getConnection(url, user, password);
											con = DriverManager.getConnection(url, user, password);
											 Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
								                ResultSet rs = st.executeQuery("select * from players");
								                rs = st.getResultSet();

								                rs.moveToInsertRow();
								                rs.updateString(2, warriorName);
								                rs.insertRow();


								                rs = st.executeQuery("select * from players");
								                rs = st.getResultSet();
								                rs.last();
								                int playerID = rs.getInt(1);
								                System.out.println("dentro");
										setDefaultCloseOperation(EXIT_ON_CLOSE);
										warriorName=selectedName.getText();
										alliedCharacter.setPlayerName(warriorName);
										} catch (SQLException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										namewarwepP.setVisible(false);
										//Random Enemy Generation
										System.out.println("antes"+getAlliedCharacter());
										
										//Warrior enemy= new Warrior();
										System.out.println("antes"+enemy);
										Weapon enemyWeapon= new Weapon();
										int randomEnemy=(int)(Math.random()*3);
										boolean loop=true;
										Warrior model=warriors.get(randomEnemy);
										enemy= new Warrior();
										enemy.setAgility(model.getAgility());
										enemy.setId(model.getId());
										enemy.setName(model.getName());
										enemy.setRace(model.getRace());
										enemy.setPhoto(model.getImage());
										enemy.setHp(model.getHp());
										enemy.setStrength(model.getStrength());
										enemy.setDefense(model.getDefense());
										enemy.setAgility(model.getAgility());
										enemy.setSpeed(model.getSpeed());
										enemy.setWeapon(model.getWeapon());
										enemy.setPoints(model.getPoints());
										enemy.setAllied(true);
										while (loop){
											int randomWeapon=(int)(Math.random()*9);
											enemyWeapon=weapons.get(randomWeapon);
											if (enemyWeapon.getRace().contains(enemy.getRace())) {		
												enemy.setWeapon(enemyWeapon);
												loop=false;
												System.out.println(getAlliedCharacter());
												System.out.println(enemy);
												
											}
										}
										//Battle Starter
										System.out.println(getAlliedCharacter());
										System.out.println("soy el enemigo"+enemy);
										BattleInterfaces battle= new BattleInterfaces(getAlliedCharacter(),enemy);
									
										
									}
								});
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								
							}
						}
						);
				
		}

public Warrior getAlliedCharacter() {
	return alliedCharacter;
}

public void setAlliedCharacter(Warrior alliedCharacter) {
	this.alliedCharacter = alliedCharacter;
}

		
	}






class Button extends JButton{
	private int id = 0;
	public Button(ImageIcon nombre, int id) {
		super(nombre);
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}