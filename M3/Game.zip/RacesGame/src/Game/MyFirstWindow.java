package Game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;


public class MyFirstWindow {

	public static void main(String[] args) throws IOException {
		new Marco();

	}

}

class Marco extends JFrame {
	JButton buttons[] = new JButton[5];
	int hp = 60;
	int maxHp = hp;
	JProgressBar healthBar;
	JProgressBar strengthBar;
	JProgressBar dexterityBar;
	JProgressBar speedBar;
	JProgressBar defenseBar;
	
	public Marco(){
		this.setSize(500, 400);
		this.setTitle("Progress Bar Test");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
			
		JPanel healthBarPanel = new JPanel();
		healthBarPanel.setSize(10,200);
		
		healthBar = new JProgressBar(0,100);
		healthBar.setStringPainted(true);
		healthBar.setPreferredSize(new Dimension(200,10));
		healthBar.setForeground(Color.green);
		healthBar.setValue(100);
		healthBarPanel.add(healthBar);
		
		this.add(healthBarPanel, BorderLayout.NORTH);
		
		JPanel statsPanel = new JPanel();
		statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.PAGE_AXIS));
		
		strengthBar = new JProgressBar(0,11);
		strengthBar.setPreferredSize(new Dimension(100,5));
		strengthBar.setForeground(Color.red);
		strengthBar.setValue(7);
		
		dexterityBar = new JProgressBar(0,11);
		dexterityBar.setPreferredSize(new Dimension(100,5));
		dexterityBar.setForeground(Color.magenta);
		dexterityBar.setValue(6);
		
		speedBar = new JProgressBar(0,11);
		speedBar.setPreferredSize(new Dimension(100,5));
		speedBar.setForeground(Color.yellow);
		speedBar.setValue(7);
		
		defenseBar = new JProgressBar(0,11);
		defenseBar.setPreferredSize(new Dimension(100,5));
		defenseBar.setForeground(Color.blue);
		defenseBar.setValue(3);
		
		statsPanel.add(strengthBar);
		statsPanel.add(dexterityBar);
		statsPanel.add(speedBar);
		statsPanel.add(defenseBar);

		this.add(statsPanel, BorderLayout.CENTER);
		
		buttons[0] = new JButton("Damage");
		this.add(buttons[0], BorderLayout.SOUTH);
		
		this.setResizable(false);
		
		this.setVisible(true);
		
		buttons[0].addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						hp = hp - (int)(Math.random()*20);
						if (hp < 0) {
							hp = 0;
						}
						healthBar.setValue(hp*100/maxHp);
						
						if (healthBar.getValue() < 25) {
							healthBar.setForeground(Color.red);
						}
						else if (healthBar.getValue() < 51) {
							healthBar.setForeground(Color.yellow);
						}
						
						
					}
				}
				);
		
	}		
		
}
