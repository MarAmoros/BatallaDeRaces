package Game;

import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import Characters.*;
import Characters.Warrior;
import Weapons.*;

public class Battle {

	
	public static void main(String[] args) {
		Random rn = new Random();

		Scanner sc= new Scanner(System.in);
		
		boolean characterSelected=false;
		boolean weaponSelected=false;
		boolean fighting=true;
		int option, character=0, weapon;
		Warrior alliedCharacter = null, enemyCharacter= null;
		Warrior attacker, defender;
		Battle b = new Battle();
		
		WeaponContainer wp=new WeaponContainer();
		wp.setWeapons(wp.getWeapons());
		System.out.println(wp.getWeapons());
		
		WarriorContainer wc=new WarriorContainer();
		wc.setWarriors(wc.getWarrios());
		System.out.println(wc.getWarrios());
		
		Warrior ally = (Warrior) wc.getWarrios().get(1);
		ally.setWeapon( (Weapon) wp.getWeapons().get(1));
		ally.setAllied(true);
		System.out.println(ally.getAllied());
		
		Warrior memory = (Warrior) wc.getWarrios().get(rn.nextInt(3));
		Warrior enemy = newEnemy(memory);
		ArrayList<Weapon> possibleWeapons= new ArrayList<Weapon>();
		for (Weapon w : wp.getWeapons()) {
			if(w.getRace().contains(enemy.getRace())) {
				possibleWeapons.add(w);
				System.out.println(w);
			}
			
		}
		int total = possibleWeapons.size();
		
		enemy.setWeapon(possibleWeapons.get(total-1));
		//new Frame();
		new BattleInterfaces(ally, enemy);

	
	}
	
public static Warrior newEnemy(Warrior memory){
	Warrior enemy = null;
	if (memory.getRace().compareToIgnoreCase("Human")==0){
		enemy = new Human(memory.getId(), memory.getName(), memory.getRace(), memory.getImage(), memory.getHp(), memory.getStrength(), memory.getDefense(), memory.getAgility(), memory.getSpeed(), memory.getPoints()); 
		enemy.setAllied(false);
	}else if (memory.getRace().compareToIgnoreCase("Dwarf")==0) {
		enemy = new Dwarf(memory.getId(), memory.getName(), memory.getRace(), memory.getImage(), memory.getHp(), memory.getStrength(), memory.getDefense(), memory.getAgility(), memory.getSpeed(), memory.getPoints()); 
		enemy.setAllied(false);
	}else if (memory.getRace().compareToIgnoreCase("Elf")==0) {
		enemy = new Elf(memory.getId(), memory.getName(), memory.getRace(), memory.getImage(), memory.getHp(), memory.getStrength(), memory.getDefense(), memory.getAgility(), memory.getSpeed(), memory.getPoints()); 
		enemy.setAllied(false);
	}
	return enemy;
}
class ConnectionDB {
	public ConnectionDB() {
		String url="jdbc:mysql://localhost/race_war?serverTimezone=UTC";
		String user="user";
		String password="user";
		String warriors="select * from warriors";
		int id;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, user, password);
			PreparedStatement pst = con.prepareStatement(warriors);
			ResultSet rs=pst.executeQuery(warriors);
			while (rs.next()) {
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(4));
			}
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}}



