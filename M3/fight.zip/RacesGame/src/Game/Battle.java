package Game;

import java.util.Random;
import java.util.Scanner;

import Characters.*;
import Characters.Character;
import Weapons.*;

public class Battle {

	
	public static void main(String[] args) {
		Random rn = new Random();

		Scanner sc= new Scanner(System.in);

		boolean characterSelected=false;
		boolean weaponSelected=false;
		boolean fighting=true;
		int option, character=0, weapon;
		Character alliedCharacter = null, enemyCharacter= null;
		Character attacker, defender;
		Battle b = new Battle();
		do {
		System.out.println("1.-Figth\n 2.-Create Character\n 3.-Select Weapon\n 4.-Exit\n Choose Option: ");
		option = sc.nextInt();
		switch (option) {
		case 1:
			if (characterSelected && weaponSelected) {
				enemyCharacter=b.generateEnemy(enemyCharacter);
				System.out.println("Ally"+alliedCharacter);
				System.out.println("Enemey"+enemyCharacter);
				alliedCharacter.setSpeed(alliedCharacter.getSpeed()+alliedCharacter.getWeapon().getSpeed());
				alliedCharacter.setStrength(alliedCharacter.getStrength()+alliedCharacter.getWeapon().getStrength());
				enemyCharacter.setSpeed(enemyCharacter.getSpeed()+enemyCharacter.getWeapon().getSpeed());
				enemyCharacter.setStrength(enemyCharacter.getStrength()+enemyCharacter.getWeapon().getStrength());
				if (alliedCharacter.getSpeed()>enemyCharacter.getSpeed()) {
					attacker=alliedCharacter;
					defender=enemyCharacter;
				} else if (alliedCharacter.getSpeed()<enemyCharacter.getSpeed()) {
					attacker=enemyCharacter;
					defender=alliedCharacter;
				}else if (alliedCharacter.getAgility()>enemyCharacter.getAgility()) {
					attacker=alliedCharacter;
					defender=enemyCharacter;
				}else if (alliedCharacter.getAgility()<enemyCharacter.getAgility()) {
					attacker=enemyCharacter;
					defender=alliedCharacter;
				} else {
					int chooseFirst=rn.nextInt(2)+1;
					if (chooseFirst==1) {attacker=alliedCharacter;defender=enemyCharacter;} else {attacker=enemyCharacter; defender=alliedCharacter;}
				}
				while (attacker.getHp()>0 && defender.getHp()>0) {
					if (fighting) {
						int accuracity,defense, atackDamage;
						System.out.println(attacker.getName()+" torn: ");
						accuracity = rn.nextInt(100)+1;
						if (attacker.getAgility()*10>accuracity) {
							defense = rn.nextInt(50)+1;
						if (defender.getAgility()>defense) {
							System.out.println(defender.getName()+" dodge the attack.");
						}else {
							atackDamage = attacker.getStrength()-defender.getDefense();
							defender.setHp(defender.getHp()-atackDamage);
							System.out.println(defender.getName()+" has recibed "+atackDamage+" points of damage.");
						}
						}else {
							System.out.println(attacker.getName()+" miss the attack.");
						}
						fighting=false;
					} else {
						int number = rn.nextInt(100)+1;
						Character transition;
						if(attacker.getSpeed()<=defender.getSpeed()) {
							//Change defensor to attacker
							transition=defender; defender=attacker; attacker=transition;
						} else if(((attacker.getSpeed()-defender.getSpeed())*10)<number){
							//Change defensor to attacker.
							transition=defender; defender=attacker; attacker=transition;
						}
						
						fighting = true; 
					}
				}
				if (attacker.getHp()<=0) {System.out.println("Atacant has debilited");}
				else if(defender.getHp()<=0) {System.out.println("Defender has debilited");}
				
				
				
				
			} else {
				System.out.println("You have to create caracter and select weapon before figth");
			}
			break;
		case 2:
			String name;

			if (characterSelected) {
				System.out.println("You already have created a character.");
			} else {
				System.out.println("1.- Dwarg\n 2.-Human\n 3.-Elf\n Choose Character: ");
				character = sc.nextInt();
				sc.nextLine();
				switch (character) {
				case 1:
					alliedCharacter = new Dwarf();
					System.out.println("Introduce your Dwarf's name: ");
					name = sc.nextLine();
					alliedCharacter.setName(name);
					characterSelected = true;
					break;
				case 2:
					alliedCharacter = new Human();
					System.out.println("Introduce your Human's name: ");
					name = sc.nextLine();
					alliedCharacter.setName(name);
					characterSelected = true;
					break;
				case 3:
					alliedCharacter = new Elf();
					System.out.println("Introduce your Elf's name: ");
					name = sc.nextLine();
					alliedCharacter.setName(name);
					characterSelected = true;
					break;
				}
			}
			break;
		case 3:
			if (weaponSelected) {
				System.out.println("You already have selected a weapo.");
			}else if (characterSelected && weaponSelected==false) {
				alliedCharacter.chooseWeapon(sc);
				weaponSelected = true;
				}
			else {
				System.out.println("You have to create the character before selecting a weapon.");
			}
			break;
		case 4:
			break;
		}} while (option!=4);
				
	}
	public Character generateEnemy(Character enemy) {
		Random rn = new Random();
		int enemyRace;
		int enemyWeapon;
		enemyRace=(rn.nextInt(3)+1);
		System.out.println("Random generated Raze: "+enemyRace);
		switch (enemyRace) {
		case 1:
			enemy = new Dwarf();
			enemyWeapon=rn.nextInt(3)+1;
			System.out.println("Random generated Weapon: "+enemyWeapon);
			enemy.chooseEnemyWeapon(enemyWeapon);
			break;
		case 2:
			enemy = new Human();
			enemyWeapon = rn.nextInt(7)+1;
			System.out.println("Random generated Weapon: "+enemyWeapon);
			enemy.chooseEnemyWeapon(enemyWeapon);
			break;
		case 3:
			enemy = new Elf();
			enemyWeapon = rn.nextInt(6)+1;
			System.out.println("Random generated Weapon: "+enemyWeapon);
			enemy.chooseEnemyWeapon(enemyWeapon);
			break;
		}
		enemy.setName("Bad boy");
		return enemy;
	}	
}


