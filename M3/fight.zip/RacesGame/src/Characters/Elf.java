package Characters;

import java.util.Scanner;

import Weapons.Bow;
import Weapons.Dagger;
import Weapons.Dirk;
import Weapons.DoubleSwords;
import Weapons.Scimitar;
import Weapons.Sword;

public class Elf extends Character{
	
	public Elf() {
		super.setHp(40);
		super.setStrength(4);
		super.setDefense(2);
		super.setAgility(7);
		super.setSpeed(7);
	}

	@Override
	public void chooseWeapon(Scanner sc) {
		int weapon= 0;
		System.out.println("1.-Dagger\n 2.-Sword\n 3.-Double Swords\n 4.-Scimitar\n 5.-Bow\n 6.-Dirk\n Choose One");
		weapon = sc.nextInt();
		switch (weapon) {
		case 1:
			setWeapon(new Dagger());
			break;
		case 2:
			setWeapon(new Sword());
			break;
		case 3:
			setWeapon(new DoubleSwords());
			break;
		case 4:
			setWeapon(new Scimitar());
			break;
		case 5:
			setWeapon(new Bow());
			break;
		case 6:
			setWeapon(new Dirk());
			break;
		}		
	}

	@Override
	public void chooseEnemyWeapon(int enemyWeapon) {
		switch (enemyWeapon) {
		case 1:
			setWeapon(new Dagger());
			break;
		case 2:
			setWeapon(new Sword());
			break;
		case 3:
			setWeapon(new DoubleSwords());
			break;
		case 4:
			setWeapon(new Scimitar());
			break;
		case 5:
			setWeapon(new Bow());
			break;
		case 6:
			setWeapon(new Dirk());
			break;
		}		
	}
	
	 
}
