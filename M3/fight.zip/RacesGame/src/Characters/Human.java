package Characters;

import java.util.Scanner;

import Weapons.*;


public class Human extends Character{

	public Human() {
		super.setHp(50);
		super.setStrength(5);
		super.setDefense(3);
		super.setAgility(6);
		super.setSpeed(5);
	}

	@Override
	public void chooseWeapon(Scanner sc) {
		int weapon = 0;
		System.out.println("1.-Dagger\n 2.-Sword\n 3.-Axe\n 4.-Dobule Swords\n 5.-Scimitar\n 6.-Katana\n 7.-Dirk\n Choose One");
		weapon = sc.nextInt();
		switch (weapon) {
		case 1:
			setWeapon(new Dagger());
			break;
		case 2:
			setWeapon(new Sword());
			break;
		case 3:
			setWeapon(new Axe());
			break;
		case 4:
			setWeapon(new DoubleSwords());
			break;
		case 5:
			setWeapon(new Scimitar());
			break;
		case 6:
			setWeapon(new Katana());
			break;
		case 7:
			setWeapon(new TwoHandedAxe());
			break;
		}		
	}

	@Override
	public void chooseEnemyWeapon(int enemyWeapon) {
		switch (enemyWeapon) {
		case 1:
			setWeapon(new Dagger());
			break;
		case 2:
			setWeapon(new Sword());
			break;
		case 3:
			setWeapon(new Axe());
			break;
		case 4:
			setWeapon(new DoubleSwords());
			break;
		case 5:
			setWeapon(new Scimitar());
			break;
		case 6:
			setWeapon(new Katana());
			break;
		case 7:
			setWeapon(new TwoHandedAxe());
			break;
		}
	}
	
}
