package Characters;

import java.util.Scanner;

import Weapons.Axe;
import Weapons.Dirk;
import Weapons.Sword;
import Weapons.TwoHandedAxe;
import Weapons.Weapon;

public class Dwarf extends Character{
	
	public Dwarf() {
		super.setHp(60);
		super.setStrength(6);
		super.setDefense(4);
		super.setAgility(5);
		super.setSpeed(3 );
	}

	@Override
	public void chooseWeapon(Scanner sc) {
		int weapon = 0;
		System.out.println("1.-Sword\n 2.-Axe\n 3.-Dirk\n 4.-Two-Handed Axe\n Choose One:");
		weapon = sc.nextInt();
		switch (weapon) {
		case 1:
			setWeapon(new Sword());
			break;
		case 2:
			setWeapon(new Axe());
			break;
		case 3: 
			setWeapon(new Dirk());
			break;
		case 4:
			setWeapon(new TwoHandedAxe());
			break;
		}		
	}

	@Override
	public void chooseEnemyWeapon(int enemyWeapon) {
		switch (enemyWeapon) {
		case 1:
			setWeapon(new Sword());
			break;
		case 2:
			setWeapon(new Axe());
			break;
		case 3: 
			setWeapon(new Dirk());
			break;
		case 4:
			setWeapon(new TwoHandedAxe());
			break;
		}
	}
}
