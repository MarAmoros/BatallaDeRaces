package Characters;

import java.util.Scanner;

import Weapons.Weapon;

public abstract class Character{
	private String name;
	private int hp;
	private int strength;
	private int defense;
	private int agility;
	private int speed;
	private Weapon object;
	
	public Character() {

	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getDefense() {
		return defense;
	}

	public void setDefense(int defense) {
		this.defense = defense;
	}

	public int getAgility() {
		return agility;
	}

	public void setAgility(int agility) {
		this.agility = agility;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public void setWeapon(Weapon object) {
		this.object=object;
	}

	public Weapon getWeapon() {
		return object;
	}
	@Override
	public String toString() {
		return	this.getClass().getName()+" [name= "+name+"hp=" + hp + ", strength=" + strength + ", defense=" + defense + ", agility=" + agility
				+ ", speed=" + speed + "] "+object;
	}
	
	public abstract void chooseWeapon(Scanner sc);
	public abstract void chooseEnemyWeapon(int enemyWeapon);

	
	
}
