package Weapons;

public class Sword extends Weapon {
	
	public Sword() {
		super.setSpeed(1);
		super.setStrength(1);
	}
}
