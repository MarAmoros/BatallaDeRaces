package Weapons;

public class Axe extends Weapon {
	
	public Axe() {
		super.setSpeed(0);
		super.setStrength(3);
	}
}
