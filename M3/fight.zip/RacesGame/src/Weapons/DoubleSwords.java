package Weapons;

public class DoubleSwords extends Weapon {

	public DoubleSwords() {
		super.setSpeed(2);
		super.setStrength(2);
	}
}
