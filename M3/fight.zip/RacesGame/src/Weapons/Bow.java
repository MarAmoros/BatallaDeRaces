package Weapons;

public class Bow extends Weapon {

		public Bow() {
			super.setSpeed(5);
			super.setStrength(1);
		}
}
