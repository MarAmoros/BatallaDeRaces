package Weapons;

public class TwoHandedAxe extends Weapon {

		public TwoHandedAxe() {
			super.setSpeed(0);
			super.setStrength(5);
		}
}
